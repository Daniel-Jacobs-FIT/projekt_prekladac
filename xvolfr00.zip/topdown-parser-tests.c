#include "topdown-parser.h"


int main(void)
{
	PRG_nt();
    //printf("EXIT_CODE = %d\n", EXIT_CODE);
	return EXIT_CODE;
}
