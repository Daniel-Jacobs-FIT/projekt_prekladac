/* Projekt: Implementace překladače imperativního jazyka IFJ22
 * Autoři: xvolr00*/
#ifndef UTILS_H
#define UTILS_H

extern int EXIT_CODE;

#endif
