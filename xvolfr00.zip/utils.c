/* Projekt: Implementace překladače imperativního jazyka IFJ22
 * Autoři: xvolr00*/
#include "utils.h"

int EXIT_CODE;
